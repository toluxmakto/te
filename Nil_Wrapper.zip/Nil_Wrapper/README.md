# Nil_Wrapper

Lua and Luau source obfuscation wrapper.

## Requirements

- Node.js 20 or newer

## Install

    npm install

## Use

    node bin/wrap.mjs input.lua output.lua

Select the pages profile with:

    node bin/wrap.mjs --profile pages input.lua output.lua

The default profile is packet. The pages profile also accepts the CLI options shown by running the command without valid input and output paths.

The input and output paths must differ, and the output file must not already exist.
