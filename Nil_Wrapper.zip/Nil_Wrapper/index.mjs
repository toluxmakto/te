import { randomBytes } from 'node:crypto';
import { wrapOpaqueLuaSourceAsNil } from './runtime/__nil.mjs';
import { wrapSourceWithPages } from './runtime/pages.mjs';

/** Wrap the complete input as opaque bytes; compile only our forwarding bridge. */
export function wrapSource(source, options = {}) {
  if (!options || typeof options !== 'object' || Array.isArray(options)) {
    throw new TypeError('Wrapper options must be an object');
  }
  for (const name of ['wireSource', 'opaqueChunks', 'entryName']) {
    if (name in options) throw new TypeError(`${name} is reserved for the internal wrapper`);
  }
  const { profile = 'packet', ...settings } = options;
  if (!['packet', 'pages'].includes(profile)) throw new TypeError('Unknown wrapper profile');
  if (profile === 'pages') return wrapSourceWithPages(source, settings);
  for (const name of ['packetLayout', 'sharedHandlers', 'wordFeedback', 'denseMetadata', 'callableEntry', 'identityWitness', 'nonlinearFeedback', 'compressionMode', 'entropyCoding', 'compactTransport', 'nativeCipher', 'cfgResultLinks', 'boundPages', 'leanRuntime', 'semanticReceipts', 'keyedDirectory', 'narrowRecords', 'entropyStreams', 'compactPrototypeMetadata', 'compactRegisters', 'bitPackedRecords', 'bitPackedConstants', 'bufferLanes']) {
    if (name in settings) throw new TypeError(name + ' requires the pages profile');
  }
  const entryName = 'e' + randomBytes(12).toString('hex');
  return wrapOpaqueLuaSourceAsNil(source, { ...settings, entryName });
}
